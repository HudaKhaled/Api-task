1. clone the project from the repo
2. run the tests from testng.xml
3. postman project and credentials are included in postmanProject folder

