package utils;

public class Credentials {

    private static String token="ATTA53808e9032db8ec897ac386d20a987e13577aba10d8b42847b5ae48542c5a898FC39ADAB";
    private static String key="9a4df43b5ef0d974678de474fd0cc579";

    public static String getKey() {
        return key;
    }

    public static String getToken() {
        return token;
    }

    public static void setKey(String key) {
        Credentials.key = key;
    }

    public static void setToken(String token) {
        Credentials.token = token;
    }
}
