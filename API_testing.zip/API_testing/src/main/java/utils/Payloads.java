package utils;

public class Payloads {

    public static String createOrganizationPayload() {
        return "{\"displayName\":\"Udacity\",\n" +
                "\"desc\":\"Creating a test Org. for API automation testing project\",\n" +
                "\"name\":\"api automation testing\"\n" + "}";
    }

    public static String createBoardPayload(String orgID){
        return "{\n" +
                "    \"name\":\"Rest Assured Testing Board\",\n" +
                "\"idOrganization\":\""+orgID+"\"\n" + "}";
    }

    public static String createListPayload(String boardID){
        return "{\n" +
                "    \"name\":\"API Testing\",\n" +
                "    \"idBoard\":\""+boardID+"\"\n" + "}";
    }
}
