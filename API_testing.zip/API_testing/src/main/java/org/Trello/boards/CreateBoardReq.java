package org.Trello.boards;

import utils.Credentials;
import utils.EndPoints;
import utils.Payloads;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import static io.restassured.RestAssured.given;

public class CreateBoardReq {
    public static Response createBoardResponse(String org_ID) {
        RestAssured.baseURI = "https://api.trello.com";
        return given().header("Content-Type", "application/json").
                body(Payloads.createBoardPayload(org_ID)).
                queryParam("token", Credentials.getToken()).
                queryParam("key", Credentials.getKey()).
                when().post(EndPoints.createBoardEndPoint()).
                then().extract().response();
    }

    public static JsonPath getBoardJS(Response response){
        return new JsonPath(response.asString());
    }

}
