package org.Trello.Tests;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import org.Trello.boards.CreateBoardReq;
import org.Trello.boards.DeleteBoardReq;
import org.Trello.boards.GetListsPerBoard;
import org.Trello.lists.ArchiveListReq;
import org.Trello.lists.CreateListReq;
import org.Trello.members.GetMemberOrgReq;
import org.Trello.members.GetMemberReq;
import org.Trello.organizations.CreateOrgRequest;
import org.Trello.organizations.DeleteOrgRequest;
import org.Trello.organizations.GetBoardsPerOrg;
import org.testng.Assert;
import org.testng.annotations.Test;

public class EndToEndTest {

    Response CreateOrganizationResponse= CreateOrgRequest.createOrganizationResponse();
    JsonPath CreateOrganizationResponseBody=CreateOrgRequest.createOrgJs(CreateOrganizationResponse);
    String org_ID=CreateOrganizationResponseBody.get("id");
    Response createBoardResponse = CreateBoardReq.createBoardResponse(org_ID);
    JsonPath createBoardResponseBody = CreateBoardReq.getBoardJS(createBoardResponse);
    String board_ID=createBoardResponseBody.get("id");
    Response getBoardsPerOrgResponse= GetBoardsPerOrg.getBoardsPerOrg(org_ID);
    JsonPath getBoardsPerOrgResponseBody=GetBoardsPerOrg.getBoardsPerOrgsJs(getBoardsPerOrgResponse);

    Response createListResponse = CreateListReq.createListResponse(board_ID);
    JsonPath createListResponseBody=CreateListReq.getcreateListJS(createListResponse);
    String list_ID = CreateListReq.getListID(createListResponseBody);

    String member_ID= GetMemberReq.getmemberID(GetMemberReq.getMemberJS(GetMemberReq.getMemberResponse()));

    Response getMemberOrgsResponse = GetMemberOrgReq.getMemberOrgsResponse(member_ID);
    JsonPath getMemberOrgsResponseBody = GetMemberOrgReq.getMemberOrgJs(getMemberOrgsResponse);

    Response archiveListResponse= ArchiveListReq.archiveListResponse(list_ID);
    JsonPath archiveListResponseBody=ArchiveListReq.archiveListJS(archiveListResponse);

    Response getListsPerBoardResponse= GetListsPerBoard.getListsPerBoardResponse(board_ID);
    JsonPath getListsPerBoardResponseBody=GetListsPerBoard.getListsPerBoardJs(getListsPerBoardResponse);

    Response deleteBoardResponse= DeleteBoardReq.deleteBoardResponse(board_ID);
    JsonPath deleteBoardResponseBody=DeleteBoardReq.getListsPerBoardJs(deleteBoardResponse);
    Response deleteOrganizationResponse= DeleteOrgRequest.deleteOrganizationResponse(org_ID);

    @Test
    public void createOrgTest(){
        Assert.assertEquals(CreateOrganizationResponse.statusCode(),200);
        Assert.assertEquals(CreateOrganizationResponseBody.get("displayName"),"Udacity");
        Assert.assertEquals(CreateOrganizationResponseBody.get("idMemberCreator"),member_ID);
        Assert.assertTrue(CreateOrganizationResponse.header("Content-Type").contains("application/json"));
    }

    @Test
    public void setGetMemberOrgTest(){
        Assert.assertEquals(getMemberOrgsResponse.statusCode(), 200);
        int orgCount = getMemberOrgsResponseBody.getInt("id.size()");
        Assert.assertTrue(orgCount > 0);
        for (int i = 0; i < orgCount; i++) {
            Assert.assertEquals(getMemberOrgsResponseBody.get("idMemberCreator[" + i + "]"), member_ID);}
        for (int i = 0; i < orgCount; i++) {
            if (getMemberOrgsResponseBody.get("id[" + i + "]").equals(org_ID)) {
                Assert.assertEquals(getMemberOrgsResponseBody.get("id[" + i + "]"), org_ID);
            } } }

    @Test
    public void createBoardTest(){
        Assert.assertEquals(createBoardResponse.statusCode(), 200);
        Assert.assertEquals(createBoardResponseBody.get("name"), "Rest Assured Testing Board");
        Assert.assertEquals(createBoardResponseBody.get("idOrganization"), org_ID);
        Assert.assertEquals(createBoardResponseBody.get("closed"), false);
    }
    @Test
    public void getBoardPerOrgTest(){
        int boardsCount=getBoardsPerOrgResponseBody.getInt("id.size()");
        Assert.assertEquals(getBoardsPerOrgResponse.statusCode(),200);
        Assert.assertTrue(boardsCount ==1);
        Assert.assertEquals(getBoardsPerOrgResponseBody.get("idMemberCreator[0]"), member_ID);
    }
    @Test
    public void createListTest(){
        Assert.assertEquals(createListResponseBody.get("name"), "API Testing");
        Assert.assertEquals(createListResponseBody.get("idBoard"), board_ID);
        Assert.assertEquals(createListResponseBody.get("closed"), false);
}
    @Test
    public void setGetListsPerBoardTest(){
    int numOfLists=getListsPerBoardResponseBody.getInt("id.size()");
    Assert.assertEquals(getListsPerBoardResponse.statusCode(), 200);
    Assert.assertTrue(numOfLists >= 3);
        for (int i=0;i<numOfLists;i++)
        {Assert.assertEquals(getListsPerBoardResponseBody.get("idBoard["+i+"]"),board_ID);}
    }
    @Test
    public void archiveListTest(){
    Assert.assertEquals(archiveListResponse.statusCode(),200);
    Assert.assertEquals(archiveListResponseBody.get("id"),list_ID);
    Assert.assertEquals(archiveListResponseBody.get("idBoard"),board_ID);
    Assert.assertEquals(archiveListResponseBody.get("closed"),true);
}
    @Test
    public void deleteBoardTest(){
    Assert.assertEquals(deleteBoardResponse.statusCode(),200);
    Assert.assertEquals(deleteBoardResponseBody.get("_value"),null);
    Assert.assertTrue(deleteBoardResponse.header("Content-Type").contains("application/json"));
    }
    @Test
    public void deleteOrganizationTest(){
    Assert.assertEquals(deleteOrganizationResponse.statusCode(),200);
}}
